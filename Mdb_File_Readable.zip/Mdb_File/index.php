<?php

// $dbName = $_SERVER["DOCUMENT_ROOT"] . "\Mdb_File\File\Campaign_Template.mdb";
    
//     if (!file_exists($dbName)) 
//     {
//         die("Could not find database file.");
//     }
    
//     $db = new PDO("odbc:DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$dbName; Uid=; Pwd=;");

//     $sql  = "SELECT First_Name FROM Campaign_Template";
//     // $sql .= " WHERE id = " . $productId;

//     $result = $db->query($sql);
//     $row = $result->fetch();

//     echo $productPrice = $row["First_Name"];


    $odbc = odbc_connect("Campaign_Template", "", "");

    if (!$odbc)
    {
        die("Could not find database file.");
    }

    $sql  = "SELECT First_Name FROM Campaign_Table";
    $rs = odbc_exec($odbc, $sql);

    while (odbc_fetch_row($rs))
    {
       echo $name = odbc_result($rs, "First_Name");
    }
